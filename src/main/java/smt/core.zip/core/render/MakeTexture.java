package smt.core.render;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class MakeTexture {

	private BufferedImage bufImg;
	private String tag;
	private int width, height;

	public MakeTexture(String tag, int width, int height) {
		this.tag = tag;
		this.bufImg = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
		this.width = width;
		this.height = height;
	}

	public MakeTexture(String tag) {
		this.tag = tag;

	}

	public MakeTexture() {

	}

	public MakeTexture set(String block_name) {
		String modid = "minecraft";
		this.tag = block_name.replace(":", "_");

		int index = block_name.indexOf(':');
		if (index >= 0) {
			if (index > 1) modid = block_name.substring(0, index);
			block_name = block_name.substring(index + 1, block_name.length());
		}
		modid = modid.toLowerCase();
		block_name = "textures/blocks/" + block_name + ".png";

		set(new ResourceLocation(modid, block_name));
		return this;
	}

	public MakeTexture set(ResourceLocation rl) {
		try {
			set(ImageIO.read(Minecraft.getMinecraft().getResourceManager().getResource(rl).getInputStream()));
		} catch (IOException e) {e.printStackTrace();};
		return this;
	}

	//not testing
	public MakeTexture set(File file) {
		try {
			set(ImageIO.read(file));
		} catch (IOException e) {e.printStackTrace();};
		return this;
	}

	//crash - need fix
	public MakeTexture set(URL url) {
		try {
			set(ImageIO.read(url));
		} catch (IOException e) {e.printStackTrace();};
		return this;
	}

	public MakeTexture set(BufferedImage bufImg) {
		this.bufImg = bufImg;
		this.width = bufImg.getWidth();
		this.height = bufImg.getHeight();
		return this;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public MakeTexture colorImage(int hex) {
		colorImage(hex, 1);
		return this;
	}

	public MakeTexture colorImage(int hex, int rang) {
		for (int x = 0; x < bufImg.getWidth(); ++x) {
			for (int y = 0; y < bufImg.getHeight(); ++y) {

				int pixel_1 = bufImg.getRGB(x, y);
				int alpha_1 = (pixel_1 >> 24) & 0xFF;
				int red_1 = (pixel_1 >> 16) & 0xFF;
				int green_1 = (pixel_1 >> 8) & 0xFF;
				int blue_1 = (pixel_1 >> 0) & 0xFF;

				int alpha_c = (hex >> 24) & 0xFF;
				int red_c = (hex >> 16) & 0xFF;
				int green_c = (hex >> 8) & 0xFF;
				int blue_c = (hex >> 0) & 0xFF;

				red_1 = (red_1 + red_c * rang) / (rang + 1);
				green_1 = (green_1 + green_c * rang) / (rang + 1);
				blue_1 = (blue_1 + blue_c * rang) / (rang + 1);

				if (red_1 < 0) red_1 = 0;if (red_1 > 255) red_1 = 255;
				if (green_1 < 0) green_1 = 0;if (green_1 > 255) green_1 = 255;
				if (blue_1 < 0) blue_1 = 0;if (blue_1 > 255) blue_1 = 255;

				int alpha = Math.max(alpha_1, alpha_c);
				int red = red_1;
				int green = green_1;
				int blue = blue_1;
				int pixel = (int)alpha << 24 | (int)red << 16 | (int)green << 8 | (int)blue;

				bufImg.setRGB(x, y, pixel);
			}
		}
		return this;
	}

	public MakeTexture colorImage2(int hex) {
		for (int x = 0; x < bufImg.getWidth(); ++x) {
			for (int y = 0; y < bufImg.getHeight(); ++y) {

				int pixel_1 = bufImg.getRGB(x, y);
				int alpha_1 = (pixel_1 >> 24) & 0xFF;
				int red_1 = (pixel_1 >> 16) & 0xFF;
				int green_1 = (pixel_1 >> 8) & 0xFF;
				int blue_1 = (pixel_1 >> 0) & 0xFF;

				int alpha_c = (hex >> 24) & 0xFF;
				int red_c = (hex >> 16) & 0xFF;
				int green_c = (hex >> 8) & 0xFF;
				int blue_c = (hex >> 0) & 0xFF;

				red_1 = red_1 + red_c / 2;
				green_1 = green_1 + green_c / 2;
				blue_1 = blue_1 + blue_c / 2;

				if (red_1 < 0) red_1 = 0;if (red_1 > 255) red_1 = 255;
				if (green_1 < 0) green_1 = 0;if (green_1 > 255) green_1 = 255;
				if (blue_1 < 0) blue_1 = 0;if (blue_1 > 255) blue_1 = 255;

				int alpha = Math.max(alpha_1, alpha_c);
				int red = red_1;
				int green = green_1;
				int blue = blue_1;
				int pixel = (int)alpha << 24 | (int)red << 16 | (int)green << 8 | (int)blue;

				bufImg.setRGB(x, y, pixel);
			}
		}
		return this;
	}

	//Graphics2D graf1 = bufImg.createGraphics();
	//Graphics2D graf2 = bufImg2.createGraphics();

	public MakeTexture carvingImage(BufferedImage bufImg2) {
		width = Math.max(bufImg.getWidth(), bufImg2.getWidth());
		height = Math.max(bufImg.getHeight(), bufImg2.getHeight());

		for (int x = 0; x < width; ++x) {
			for (int y = 0; y < height; ++y) {

				int pixel_1 = bufImg.getRGB(x, y);
				int alpha_1 = (pixel_1 >> 24) & 0xFF;
				int red_1 = (pixel_1 >> 16) & 0xFF;
				int green_1 = (pixel_1 >> 8) & 0xFF;
				int blue_1 = (pixel_1 >> 0) & 0xFF;

				int pixel_2 = bufImg2.getRGB(x, y);
				int alpha_2 = (pixel_2 >> 24) & 0xFF;
				int red_2 = (pixel_2 >> 16) & 0xFF;
				int green_2 = (pixel_2 >> 8) & 0xFF;
				int blue_2 = (pixel_2 >> 0) & 0xFF;

				red_2 = red_1 + (red_2 - 127);
				green_2 = green_1 + (green_2 - 127);
				blue_2 = blue_1 + (blue_2 - 127);

				if (red_2 < 0) red_2 = 0;if (red_2 > 255) red_2 = 255;
				if (green_2 < 0) green_2 = 0;if (green_2 > 255) green_2 = 255;
				if (blue_2 < 0) blue_2 = 0;if (blue_2 > 255) blue_2 = 255;

				int alpha = Math.max(alpha_1, alpha_2);
				int red = red_2;
				int green = green_2;
				int blue = blue_2;
				int pixel = (int)alpha << 24 | (int)red << 16 | (int)green << 8 | (int)blue;

				bufImg.setRGB(x, y, pixel);

			}
		}
		return this;
	}

	//not do make
	public MakeTexture mergerImage(BufferedImage bufImg2) {
		width = Math.max(bufImg.getWidth(), bufImg2.getWidth());
		height = Math.max(bufImg.getHeight(), bufImg2.getHeight());

		for (int x = 0; x < width; ++x) {
			for (int y = 0; y < height; ++y) {

				int pixel_1 = bufImg.getRGB(x, y);
				int alpha_1 = (pixel_1 >> 24) & 0xFF;
				int red_1 = (pixel_1 >> 16) & 0xFF;
				int green_1 = (pixel_1 >> 8) & 0xFF;
				int blue_1 = (pixel_1 >> 0) & 0xFF;

				int pixel_2 = bufImg2.getRGB(x, y);
				int alpha_2 = (pixel_2 >> 24) & 0xFF;
				int red_2 = (pixel_2 >> 16) & 0xFF;
				int green_2 = (pixel_2 >> 8) & 0xFF;
				int blue_2 = (pixel_2 >> 0) & 0xFF;

				alpha_2 = (alpha_1 + (alpha_2)) / 2;
				red_2 = (red_1 + (red_2)) / 2;
				green_2 = (green_1 + (green_2)) / 2;
				blue_2 = (blue_1 + (blue_2)) / 2;

				if (alpha_2 < 0) alpha_2 = 0;if (alpha_2 > 255) alpha_2 = 255;
				if (red_2 < 0) red_2 = 0;if (red_2 > 255) red_2 = 255;
				if (green_2 < 0) green_2 = 0;if (green_2 > 255) green_2 = 255;
				if (blue_2 < 0) blue_2 = 0;if (blue_2 > 255) blue_2 = 255;

				int alpha = Math.max(alpha_1, alpha_2);
				int red = (alpha_1 > alpha_2 ? red_1 : red_2);
				int green = (alpha_1 > alpha_2 ? green_1 : green_2);
				int blue = (alpha_1 > alpha_2 ? blue_1 : blue_2);
				int pixel = (int)alpha << 24 | (int)red << 16 | (int)green << 8 | (int)blue;

				bufImg.setRGB(x, y, pixel);

			}
		}
		return this;
	}

	public MakeTexture layingImage(BufferedImage bufImg2) {
		width = Math.max(bufImg.getWidth(), bufImg2.getWidth());
		height = Math.max(bufImg.getHeight(), bufImg2.getHeight());

		for (int x = 0; x < width; ++x) {
			for (int y = 0; y < height; ++y) {

				int pixel_1 = bufImg.getRGB(x, y);
				int alpha_1 = (pixel_1 >> 24) & 0xFF;
				int red_1 = (pixel_1 >> 16) & 0xFF;
				int green_1 = (pixel_1 >> 8) & 0xFF;
				int blue_1 = (pixel_1 >> 0) & 0xFF;

				int pixel_2 = bufImg2.getRGB(x, y);
				int alpha_2 = (pixel_2 >> 24) & 0xFF;
				int red_2 = (pixel_2 >> 16) & 0xFF;
				int green_2 = (pixel_2 >> 8) & 0xFF;
				int blue_2 = (pixel_2 >> 0) & 0xFF;

				int alpha = Math.max(alpha_1, alpha_2);
				int red = (alpha_1 > alpha_2 ? red_1 : red_2);
				int green = (alpha_1 > alpha_2 ? green_1 : green_2);
				int blue = (alpha_1 > alpha_2 ? blue_1 : blue_2);

				//System.out.println(alpha_2);

				if (alpha < 0) alpha = 0;if (alpha > 255) alpha = 255;
				if (red < 0) red = 0;if (red > 255) red = 255;
				if (green < 0) green = 0;if (green > 255) green = 255;
				if (blue < 0) blue = 0;if (blue > 255) blue = 255;

				int pixel = (int)alpha << 24 | (int)red << 16 | (int)green << 8 | (int)blue;

				bufImg.setRGB(x, y, pixel);

			}
		}
		return this;
	}
	/*
	public MakeTexture layingImageWithColor(BufferedImage bufImg2) {
		width = Math.max(bufImg.getWidth(), bufImg2.getWidth());
		height = Math.max(bufImg.getHeight(), bufImg2.getHeight());

		for (int x = 0; x < width; ++x) {
			for (int y = 0; y < height; ++y) {

				int pixel_1 = bufImg.getRGB(x, y);
				int alpha_1 = (pixel_1 >> 24) & 0xFF;
				int red_1 = (pixel_1 >> 16) & 0xFF;
				int green_1 = (pixel_1 >> 8) & 0xFF;
				int blue_1 = (pixel_1 >> 0) & 0xFF;

				int pixel_2 = bufImg2.getRGB(x, y);
				int alpha_2 = (pixel_2 >> 24) & 0xFF;
				int red_2 = (pixel_2 >> 16) & 0xFF;
				int green_2 = (pixel_2 >> 8) & 0xFF;
				int blue_2 = (pixel_2 >> 0) & 0xFF;

				if (red_2 < 0) red_2 = 0;if (red_2 > 255) red_2 = 255;
				if (green_2 < 0) green_2 = 0;if (green_2 > 255) green_2 = 255;
				if (blue_2 < 0) blue_2 = 0;if (blue_2 > 255) blue_2 = 255;

				int alpha = Math.max(alpha_1, alpha_2);
				int red = (alpha_1 > alpha_2 ? red_1 : red_2);
				int green = (alpha_1 > alpha_2 ? green_1 : green_2);
				int blue = (alpha_1 > alpha_2 ? blue_1 : blue_2);
				int pixel = (int)alpha << 24 | (int)red << 16 | (int)green << 8 | (int)blue;

				bufImg.setRGB(x, y, pixel);
			}
		}
		return this;
	}
	 */
	public BufferedImage getBufferedImage() {
		return bufImg;
	}

	public ResourceLocation getTextureLocation() {
		DynamicTexture dt = new DynamicTexture(bufImg);
		return Minecraft.getMinecraft().getTextureManager().getDynamicTextureLocation(tag, dt);
	}

}
