package smt.pack.common.animation;

public interface IKey {

	float getTime();
	float getField();
	Easing getEasing();

}
